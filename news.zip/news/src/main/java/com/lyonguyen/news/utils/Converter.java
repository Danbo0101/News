package com.lyonguyen.news.utils;

public class Converter {

    public int parseInt(String number) {
        return Integer.parseInt(number);
    }
}
