This is a news website use Spring Boot, Thyme Leaf and Google Cloud API
